

import java.util.Random;

public class Matriz
{
    //Atributos de instancia
        private boolean matriz[][];
        private Random n;
    //Constructor
        public Matriz(int dimension){
            matriz = new boolean[dimension][dimension];
        }
        //Comando
        public void generarBombas(){
            n = new Random();
            for(int i=0; i<matriz.length;i++)
                for(int j=0;j<matriz[0].length;j++){
                if((n.nextInt()%2==0) && (n.nextInt()%2==0) && (n.nextInt()%2==0 ||n.nextInt()%3==0) && (n.nextInt()%2==0 || n.nextInt()%2==0))
                    matriz[i][j]= true;
                else 
                    matriz[i][j]= false;
                }
        }
        public void ponerBomba(int f, int c){
            //Asumo que son validos f y c
            matriz[f][c]= true;            
        }
        public void quitarBomba(int f, int c){
            //Asumo que son validos f y c
            matriz[f][c]= false;            
        }
        public void vaciar(){
            for(int f=0;f<matriz.length;f++)
                for(int c=0;c<matriz[0].length;c++)
                    if(matriz[f][c])matriz[f][c]=false;
        }
        public void reset(){
            this.vaciar();
            this.generarBombas();
        }
        //Consultas
        
        public int cantidadFilas(){
            return matriz.length;
        }
    
        public int cantidadColumnas(){
            return matriz[0].length;
        }
        public boolean hayBomba(int f,int c){
            return matriz[f][c];
        }
        public Matriz copy(){
        Matriz res= new Matriz(matriz.length);
            for(int f=0;f<matriz.length;f++)
                for(int c=0;c<matriz[0].length;c++)
                    if(matriz[f][c])res.ponerBomba(f,c);
        return res;          
        }
        public int totalBombas(){
            int cont=0;
            for( int i=0;i<matriz.length;i++)
                for( int j=0;j<matriz[0].length;j++)
                    if(matriz[i][j])cont++;
        return cont;
        }
        public int cantBombas(int f, int c){
            int cont=0;
            int fila=f-1;
            int columna=c-1;
            for(int i=fila; i<=f+1;i++){
                for(int j=columna; j<=c+1;j++){
                    if(i>=0 && i<this.cantidadFilas() && j>=0 && j<this.cantidadColumnas())
                        if(matriz[i][j])cont++;
                }   
            }
            return cont;
        }
        
}
