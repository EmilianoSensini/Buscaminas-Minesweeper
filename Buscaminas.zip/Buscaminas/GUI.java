/*Emiliano*/
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Image;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;

import javax.swing.*;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GUI extends JFrame {
    //Lógica de la aplicación
    //paneles
        private JPanel panelMatriz;
        private JPanel panelCeldas;
        private JPanel panelEncabezado;
        private JPanel panelBombasRestantes;
        private JPanel panelBandera;
        private JPanel panelReset;
    //botones
        private JButton [][] botones;
        private JButton botonBandera;
        private JButton botonReset;
    // Tengo que meterlo en la logica   
        private Matriz mat;
        private Matriz matBool;
        private Matriz matBandera;
        private int totalBombas ;
        private int bombasSinDescubrir;
        private boolean banderaActiva;

            
    //labels
        private JLabel bombasRestantes;
        private JLabel dificultad;
        
    //constructor
    public GUI(){
        super("Busca minas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(new Dimension(1000, 1000));
        inicializarGUI();
        setVisible(true);
    }
    //incializar los componentes
    private void inicializarGUI(){
        this.setLayout(new BorderLayout());
        
        //Armando contador de bombas
        bombasRestantes = new JLabel("0");
        dificultad = new JLabel("Dificultad: ");
        Font fuente = new Font("arial", Font.BOLD, 15);
        bombasRestantes.setFont(fuente);
        bombasRestantes.setForeground(Color.RED);
        panelBombasRestantes= new JPanel();
        //panel indicador es el rectangulo que contiene al numero
        JPanel panelIndicador = new JPanel();
        panelIndicador.setBackground(Color.BLACK);
        panelIndicador.setPreferredSize(new Dimension(60,40));
        panelIndicador.setBorder(BorderFactory.createLineBorder(Color.RED, 5));
        panelIndicador.add(bombasRestantes);
        panelBombasRestantes.add(panelIndicador);
   
        //armado del boton Bandera
        banderaActiva=false;
        botonBandera=  new JButton();
        botonBandera.addActionListener(new OyenteBotonBandera());
        botonBandera.setPreferredSize(new Dimension(40,40));
        ImageIcon banderaIcon =(new ImageIcon(new ImageIcon("bandera.png").getImage().getScaledInstance(40,40,Image.SCALE_SMOOTH)));
        botonBandera.setIcon(banderaIcon);
    
        panelBandera= new JPanel();
        panelBandera.setPreferredSize(new Dimension(40,40));
        panelBandera.add(botonBandera);
        
        //armado del boton Reset
        
        botonReset=  new JButton();
        botonReset.addActionListener(new OyenteBotonReset());
        botonReset.setPreferredSize(new Dimension(40,40));
        ImageIcon resetIcon = new ImageIcon(new ImageIcon("cara.png").getImage().getScaledInstance(40,40,Image.SCALE_SMOOTH));

        botonReset.setIcon(resetIcon);
        
        panelReset= new JPanel();
        panelReset.setPreferredSize(new Dimension(40,40));
        panelReset.add(botonReset);
        
        panelEncabezado= new JPanel(new GridLayout(1,3));
        panelEncabezado.setPreferredSize(new Dimension(400,50));
        panelEncabezado.add(panelBombasRestantes);
        panelEncabezado.add(panelReset);
        panelEncabezado.add(panelBandera);
        //armado del panel donde se muetran las celdas
        
        mat = new Matriz(30);
        matBool= new Matriz(30);
        matBandera= new Matriz(30);
        
        mat.generarBombas();
        panelCeldas= new JPanel(new FlowLayout());
        panelMatriz = new JPanel();
        panelMatriz.setPreferredSize(new Dimension(780,780));
        panelMatriz.setLayout(new GridLayout(30,30));
        inicializarBotones();
        panelCeldas.add(panelMatriz);
        
        bombasSinDescubrir=mat.totalBombas();
        bombasRestantes.setText(""+bombasSinDescubrir+"");
        
        this.add(panelCeldas,BorderLayout.CENTER);
        this.add(panelEncabezado,BorderLayout.NORTH);
    }
    private void inicializarBotones(){
        botones = new JButton[30][30];
        ImageIcon posicionIcon = new ImageIcon(new ImageIcon("neutro.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH));
        for(int i=0;i<30;i++){
            for(int j=0;j<30;j++){
                //crear el boton
                botones[i][j]=new JButton();
                //establecer su oyente
                botones[i][j].addMouseListener(new OyenteBotonCelda(i,j));
                //setear el icono
                botones[i][j].setIcon(posicionIcon);
                //Agregar el boton al panel de butacas (panelButacas)
                panelMatriz.add(botones[i][j]);
            }
        }
    }
    private void deshabilitarBotones(){
        for(int i=0; i<botones.length;i++)//por cada fila
            for(int j=0; j<botones[0].length;j++){//por cada columna
               botones[i][j].setEnabled(false);// le indicamos deshabilitar el boton 
            }
    }
    private void habilitarBotones(){
        for(int i=0; i<botones.length;i++)
            for(int j=0; j<botones[0].length;j++){
               botones[i][j].setEnabled(true);
            }
    }
    class OyenteBotonCelda extends MouseAdapter{
        private int fila;
        private int columna;
        
        public OyenteBotonCelda(int f,int c){
            fila=f;
            columna=c;
        }
        public void mousePressed(MouseEvent e) {
        if (SwingUtilities.isLeftMouseButton(e))clickDerecho(fila,columna);
        else if(SwingUtilities.isRightMouseButton(e))clickIzquierdo(fila,columna);
        }
    }
    private void clickDerecho(int fila,int col){
                int i=fila;
                int j=col;
                    if(!banderaActiva && !matBandera.hayBomba(i,j)){
                        if(mat.hayBomba(i,j) ){
                            botones[i][j].setIcon(new ImageIcon(new ImageIcon("bombaApretada.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                            for(int f=0;f<30;f++)
                                for(int c=0;c<30;c++){
                                    if(mat.hayBomba(f,c) && !(f==i && c==j))
                                        botones[f][c].setIcon(new ImageIcon(new ImageIcon("bomba.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                                    else if(matBandera.hayBomba(f,c))botones[f][c].setIcon(new ImageIcon(new ImageIcon("banderaTachada.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                                    
                                }
                            ImageIcon perderIcon = new ImageIcon(new ImageIcon("triste.png").getImage().getScaledInstance(40,40,Image.SCALE_SMOOTH));
                            botonReset.setIcon(perderIcon);
                            JOptionPane panelMensajePerder= new JOptionPane();
                            panelMensajePerder.showMessageDialog(null, "Lo siento, perdiste", "Buscaminas", JOptionPane.PLAIN_MESSAGE);
                            deshabilitarBotones();
                        }
                        else noHaybombas(i,j);
                    }
                    else if (!(matBool.hayBomba(i,j))){
                        if(!matBandera.hayBomba(i,j)){
                            botones[i][j].setIcon(new ImageIcon(new ImageIcon("bandera.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                            matBandera.ponerBomba(i,j);
                            bombasSinDescubrir--;
                        }
                        else{
                            botones[i][j].setIcon(new ImageIcon(new ImageIcon("neutro.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                            matBandera.quitarBomba(i,j);
                            bombasSinDescubrir++;
                        }
                        bombasRestantes.setText(""+bombasSinDescubrir+"");
                    
    
                    }
    }
    private void noHaybombas(int i,int j){
            matBool.ponerBomba(i,j);
            switch(mat.cantBombas(i,j)){
                    case 0:
                        botones[i][j].setIcon(new ImageIcon(new ImageIcon("0.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                        for(int f=i-1; f<=i+1;f++){
                            for(int c=j-1; c<=j+1;c++){
                                if(f>=0 && f<30 && c>=0 && c<30 && !(f==i && c==j))
                                    if(!matBool.hayBomba(f,c) && !matBandera.hayBomba(f,c)){
                                        matBool.ponerBomba(f,c);
                                        noHaybombas(f,c);
                                    }
                            }   
                        }
                    break;
                    case 1:
                        botones[i][j].setIcon(new ImageIcon(new ImageIcon("1.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                    break;
                    case 2:
                        botones[i][j].setIcon(new ImageIcon(new ImageIcon("2.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                    break;
                    case 3:
                        botones[i][j].setIcon(new ImageIcon(new ImageIcon("3.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                    break;
                    case 4:
                        botones[i][j].setIcon(new ImageIcon(new ImageIcon("4.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                    break;
                    case 5:
                        botones[i][j].setIcon(new ImageIcon(new ImageIcon("5.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                    break;
                    case 6:
                        botones[i][j].setIcon(new ImageIcon(new ImageIcon("6.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                    break;
                    case 7:
                        botones[i][j].setIcon(new ImageIcon(new ImageIcon("7.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                    break;
                    case 8:
                        botones[i][j].setIcon(new ImageIcon(new ImageIcon("8.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                    break;
                }
                if(matBool.totalBombas()==900-mat.totalBombas()){
                    ImageIcon ganarIcon = new ImageIcon(new ImageIcon("lentes.png").getImage().getScaledInstance(40,40,Image.SCALE_SMOOTH));
                    botonReset.setIcon(ganarIcon);
                    JOptionPane panelMensajeGanar= new JOptionPane();
                    panelMensajeGanar.showMessageDialog(null, "Felicitaciones, ganaste", "Buscaminas", JOptionPane.PLAIN_MESSAGE);
                    deshabilitarBotones();
                }
    }
    private void clickIzquierdo(int fila,int colu){
            int i=fila;
            int j=colu;
            if(!(matBool.hayBomba(i,j))){
                        if(!matBandera.hayBomba(i,j)){
                            botones[i][j].setIcon(new ImageIcon(new ImageIcon("bandera.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                            matBandera.ponerBomba(i,j);
                            bombasSinDescubrir--;
                        }
                        else{
                            botones[i][j].setIcon(new ImageIcon(new ImageIcon("neutro.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                            matBandera.quitarBomba(i,j);
                            bombasSinDescubrir++;
                        }
                        bombasRestantes.setText(""+bombasSinDescubrir+"");
            }
        }
        
    
    private class OyenteBotonBandera implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if (!banderaActiva){
                banderaActiva=true;
                ImageIcon banderaIcon =(new ImageIcon(new ImageIcon("bomba.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
                botonBandera.setIcon(banderaIcon);
            }
            else{
                banderaActiva=false;
                ImageIcon banderaIcon =(new ImageIcon(new ImageIcon("bandera.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
            botonBandera.setIcon(banderaIcon);
            }
        
        }
    }
    private class OyenteBotonReset implements ActionListener{
        public void actionPerformed(ActionEvent e){
            ImageIcon resetIcon = new ImageIcon(new ImageIcon("cara.png").getImage().getScaledInstance(40,40,Image.SCALE_SMOOTH));
            botonReset.setIcon(resetIcon);
            mat.reset();
            matBool.vaciar();
            matBandera.vaciar();
            for (int i =0;i<mat.cantidadFilas();i++)
                for (int j=0;j<mat.cantidadColumnas();j++) 
                    botones[i][j].setIcon(new ImageIcon(new ImageIcon("neutro.png").getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH)));
            habilitarBotones();
            bombasSinDescubrir=mat.totalBombas();
            bombasRestantes.setText(""+bombasSinDescubrir+"");

        }
    }
    
}